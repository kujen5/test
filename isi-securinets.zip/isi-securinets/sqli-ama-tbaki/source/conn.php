<?php
$dbuser ='supersqli';
$dbpass ='supersqli';
$dbname ='supersqli';
$host = 'mysql';
